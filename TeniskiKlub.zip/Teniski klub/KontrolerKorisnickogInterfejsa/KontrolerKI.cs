﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Komunikacija;
using Biblioteka;
using System.Windows.Forms;
using System.Drawing;

namespace KontrolerKorisnickogInterfejsa
{
    public class KontrolerKI
    {
        public static Komunikacija.Komunikacija komunikacija;
        public static Korisnik korisnik;
        public static Clan clan;
        public static Turnir turnir;

        public static bool poveziSeNaServer()
        {
            komunikacija = new Komunikacija.Komunikacija();
            return komunikacija.poveziSeNaServer();
        }

        public void PopuniCombo(ComboBox cmbClan, ComboBox cmbTurnir)
        {
            cmbClan.DataSource = komunikacija.vratiSveClanove();
            cmbClan.Text = "Izaberite clana!";
            cmbTurnir.DataSource = komunikacija.vratiSveTurnire();
            cmbTurnir.Text = "Izaberite turnir!";
        }

        public bool zapamtiPrijavu(ComboBox cmbTurnir, ComboBox cmbClan)
        {
            Prijava p = new Prijava();
            p.DatumPrijave = DateTime.Now;
            p.Clan = cmbClan.SelectedItem as Clan;
            if (p.Clan == null)
            {
                MessageBox.Show("Niste odabrali clana!");
                return false;
            }

            p.Turnir = cmbTurnir.SelectedItem as Turnir;
            if (p.Turnir == null)
            {
                MessageBox.Show("Niste odabrali turnir!");
                return false;
            }


            Object rez = komunikacija.zapamtiPrijavu(p);

            if (rez == null)
            {
                MessageBox.Show("Sistem ne moze da zapamti prijavu!");
                return false;
            }
            else
            {
                MessageBox.Show("Sistem je zapamtio prijavu!");
                return true;
            }
        }

        public void popuniPoljaTurnir(TextBox txtMesto,DateTimePicker dtpDatum, DataGridView dataGridView1)
        {
          
          

            txtMesto.Text = turnir.Mesto;
            dtpDatum.Value = turnir.Datum;
          
            dataGridView1.DataSource = turnir.ListaNagrada;
           
        }

       

      

        public void pretraziTurnire(TextBox txtFilter, DataGridView dataGridView1)
        {
            turnir = new Turnir();
            turnir.Uslov = "Mesto like '"+txtFilter.Text+"%'";

            List<Turnir> lista = komunikacija.pretraziTurnire(turnir) as List<Turnir>;
            dataGridView1.DataSource = lista;
            if (lista == null)
            {
                MessageBox.Show("Sistem ne moze da pronadje turnire!");
            }
            if (lista.Count == 0)
            {
                MessageBox.Show("Sistem ne moze da pronadje turnire!");
            }
            else
            {
              //  MessageBox.Show("Sistem je pronasao turnire!");
            }



        }

        public bool pronadjiTurnir(DataGridView dataGridView1)
        {
            try
            {
                turnir = dataGridView1.CurrentRow.DataBoundItem as Turnir;
                turnir = komunikacija.pronadjiTurnir(turnir) as Turnir;
                if (turnir == null)
                {
                    MessageBox.Show("Sistem ne moze da pronadje turnir!");
                    return false;
                }
                else
                {
                    MessageBox.Show("Sistem je pronasao turnir!");
                    return true;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali turnir!");
                return false;
            }
        }

        public void kreirajTurnir(GroupBox gbTurnir, TextBox txtID, Button btnKreiraj, DataGridView dataGridView1)
        {
            turnir = komunikacija.kreirajTurnir() as Turnir;

            if (turnir == null)
            {
                MessageBox.Show("Sistem ne moze da kreira turnir!");
                return;
            }
            else
            {
               
                txtID.Text = turnir.TurnirID.ToString();
                btnKreiraj.Enabled = false;
                gbTurnir.Enabled = true;             
             
                dataGridView1.DataSource = turnir.ListaNagrada;
               
            }
        }

        public bool zapamtiTurnir(TextBox txtMesto, DateTimePicker dtpDatum)
        {
            turnir.Datum = dtpDatum.Value;
            if (turnir.Datum < DateTime.Now)
            {
                MessageBox.Show("Turnir mora biti u buducnosti!");
                return false;
            }
            turnir.Mesto = txtMesto.Text;
            if (turnir.Mesto == "")
            {
                MessageBox.Show("Niste uneli mesto odrzavanja turnira!");
                return false;
            }

          

            Object rez = komunikacija.zapamtiTurnir(turnir);

            if (rez == null)
            {
                MessageBox.Show("Sistem ne moze da zapamti turnir!");
                return false;
            }
            else
            {
                MessageBox.Show("Sistem je zapamtio turnir!");
                return true;
            }

        }

        public void obrisiNagradu(DataGridView dataGridView1)
        {
            try
            {
                Nagrada n = dataGridView1.CurrentRow.DataBoundItem as Nagrada;
                turnir.ListaNagrada.Remove(n);
                int br = 1;
                foreach (Nagrada na in turnir.ListaNagrada)
                {
                    n.NagradaID = br;
                    br++;
                }

            }
            catch (Exception)
            {

               
            }
        }

       

        public void dodajNagradu(TextBox txtNagrada)
        {
            Nagrada n = new Nagrada();
            n.TurnirID = turnir.TurnirID;
            try
            {
                n.NagradaID = turnir.ListaNagrada.Max(x => x.NagradaID) + 1;
            }
            catch (Exception)
            {

                n.NagradaID = 1;
            }
           
            n.Naziv = txtNagrada.Text;
          
            turnir.ListaNagrada.Add(n);          
        }



        public void popuniDetaljeClana(TextBox txtIme, TextBox txtPrezime, DateTimePicker dtpDatum, ComboBox cmbKategorija, TextBox txtClanBR, TextBox txtMail)
        {
            cmbKategorija.DataSource = komunikacija.vratiSveKategorije();

            txtIme.Text = clan.Ime;
            txtPrezime.Text = clan.Prezime;
            dtpDatum.Value = clan.DatumRodjena;
            cmbKategorija.SelectedItem = clan.Kategorija;
            txtClanBR.Text = clan.ClanskiBroj.ToString();
            txtMail.Text = clan.Mail;
        }

        public bool obrisiClana()
        {
            Object rez = komunikacija.obrisiClana(clan);

            if (rez == null)
            {
                MessageBox.Show("Sistem ne moze da obrise clana!");
                return false;
            }
            else
            {
                MessageBox.Show("Sistem je obrisao clana!");
                return true;
            }
        }

        public void pretraziClanove(TextBox txtFilter, DataGridView dataGridView1)
        {
            clan = new Clan();
            clan.Uslov = " Ime like '"+txtFilter.Text+"%' or Prezime like '"+txtFilter.Text+"%'";

            List<Clan> lista = komunikacija.pretraziClanove(clan) as List<Clan>;
            dataGridView1.DataSource = lista;
            if (lista == null)
            {
                MessageBox.Show("Sistem ne moze da pronadje clanove!");
                return;
            }
            if (lista.Count == 0)
            {
                MessageBox.Show("Ne postoje clanovi za uneti kriterijum!");
                return;
            }
            
           // MessageBox.Show("Sistem je pronasao clanove!");

        }

        public bool pronadjiClana(DataGridView dataGridView1)
        {
            try
            {
                clan = dataGridView1.CurrentRow.DataBoundItem as Clan;

                clan = komunikacija.pronadjiClana(clan) as Clan;

                if (clan == null)
                {
                    MessageBox.Show("Sistem ne moze da pronadje clana!");
                    return false;
                }
                else
                {
                    MessageBox.Show("Sistem je pronasao clana!");
                    return true;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali clana!");
                return false;
            }
        }

        public void kreirajClana(TextBox txtID, ComboBox cmbKategorija, GroupBox gbClan, Button btnKreiraj)
        {
            gbClan.Enabled = false;
            clan = komunikacija.kreirajClana() as Clan;

            if (clan == null)
            {
                MessageBox.Show("Sistem ne moze da kreira clana!");
                btnKreiraj.Enabled = true;
            }
            else
            {
                btnKreiraj.Enabled = false;
                gbClan.Enabled = true;
                txtID.Text = clan.ClanID.ToString();
                cmbKategorija.DataSource = komunikacija.vratiSveKategorije();
                cmbKategorija.Text = "Izaberi kategoriju!";
                MessageBox.Show("Sistem je kreirao clana!");
            }

        }

        public bool zapamtiClana(TextBox txtIme, TextBox txtPrezime, DateTimePicker dtpDatum, ComboBox cmbKategorija, TextBox txtMail, TextBox txtClBroj)
        {
            clan.Ime = txtIme.Text;
            if (clan.Ime == "")
            {
                MessageBox.Show("Fali ti ime!");
                txtIme.Focus();
                return false;
            }

            // ime mora da sadrzi samo slova

            foreach (Char c in clan.Ime)
            {
                if (!Char.IsLetter(c)&&c!=' ')
                {
                    MessageBox.Show("Ime mora da sadrzi samo slova!");
                    txtIme.Focus();
                    return false;
                }
            }

            clan.Prezime = txtPrezime.Text;

            if (clan.Prezime == "")
            {
                MessageBox.Show("Niste uneli prezime!");
                txtPrezime.Focus();
                return false;
            }

            foreach (Char c in clan.Prezime)
            {
                if (!Char.IsLetter(c) && c != ' ')
                {
                    MessageBox.Show("Prezime mora da sadrzi samo slova!");
                    txtIme.Focus();
                    return false;
                }
            }

            clan.DatumRodjena = dtpDatum.Value;
           
            clan.Kategorija = cmbKategorija.SelectedItem as Kategorija;
            if (clan.Kategorija == null)
            {
                MessageBox.Show("Niste odabrali zemlju clana!");
                return false;
            }

            try
            {
                clan.ClanskiBroj = Convert.ToInt32(txtClBroj.Text);
            }
            catch (Exception)
            {

                MessageBox.Show("Clanski broj nije ispravno unet!");
                return false;
            }

            clan.Mail = txtMail.Text;

            clan.Korisnik = korisnik;
            Object rez = komunikacija.zapamtiClana(clan);

            if (rez == null)
            {
                MessageBox.Show("Sistem ne moze da zapamti clana!");
                return false;
            }
            else
            {
                MessageBox.Show("Sistem je zapamtio clana!");
                return true;
            }
        }

        public void kraj()
        {
            komunikacija.kraj();
        }

        public bool pronadjiKorisnika(TextBox txtPass)
        {
            korisnik = new Korisnik();
            korisnik.KorisnikID = txtPass.Text;

            korisnik = komunikacija.pronadjiKorisnika(korisnik) as Korisnik;

            if (korisnik == null)
            {
                MessageBox.Show("Sistem ne moze da prijavi korisnika!");
              
                txtPass.Clear();
                txtPass.Focus();
                return false;

            }
            else
            {
                MessageBox.Show("Sistem je uspesno prijavio korisnika!");
                return true;
            }
        }
    }
}
