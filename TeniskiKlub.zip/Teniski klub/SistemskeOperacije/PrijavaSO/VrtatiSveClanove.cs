﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.PrijavaSO
{
    public class VrtatiSveClanove : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {

            Clan c = new Clan();
            c.Uslov = "Ime is null";
            Sesija.Broker.dajSesiju().obrisiZaUslovVise(c);
            return Sesija.Broker.dajSesiju().dajSve(odo).OfType<Clan>().ToList<Clan>();
        }
    }
}
