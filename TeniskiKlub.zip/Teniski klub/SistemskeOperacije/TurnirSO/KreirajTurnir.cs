﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.TurnirSO
{
    public class KreirajTurnir : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            Turnir t = new Turnir();
            t.TurnirID = Sesija.Broker.dajSesiju().dajSifru(odo);
            Sesija.Broker.dajSesiju().sacuvaj(t);
            return t;
        }
    }
}
