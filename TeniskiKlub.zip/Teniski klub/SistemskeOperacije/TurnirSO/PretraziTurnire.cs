﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.TurnirSO
{
    public class PretraziTurnire : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            return Sesija.Broker.dajSesiju().dajSveZaUslovVise(odo).OfType<Turnir>().ToList<Turnir>();
        }
    }
}
