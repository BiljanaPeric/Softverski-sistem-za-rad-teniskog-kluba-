﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.TurnirSO
{
    public class UcitajTurnir : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            Turnir t = odo as Turnir;         

            Nagrada n = new Nagrada();
            n.Uslov = " TurnirID =" + t.TurnirID+"";
           t.ListaNagrada=new System.ComponentModel.BindingList<Nagrada>( Sesija.Broker.dajSesiju().dajSveZaUslovVise(n).OfType<Nagrada>().ToList<Nagrada>());          


            return t;


        }
    }
}
