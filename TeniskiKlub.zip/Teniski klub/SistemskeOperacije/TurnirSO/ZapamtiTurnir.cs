﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
using Sesija;

namespace SistemskeOperacije.TurnirSO
{
    public class ZapamtiTurnir : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            Turnir t = odo as Turnir;
            Sesija.Broker.dajSesiju().izmeni(odo);

            Nagrada n = new Nagrada();
            n.Uslov = " TurnirID =" + t.TurnirID + "";

            Broker.dajSesiju().obrisiZaUslovVise(n);

            foreach (Nagrada na in t.ListaNagrada)
            {
                 Sesija.Broker.dajSesiju().sacuvaj(na);                    
                
            }

            return 1;
        }
    }
}
