﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.ClanSO
{
    public class UcitajClana : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            Clan c = odo as Clan;
            c.Kategorija = Sesija.Broker.dajSesiju().dajZaUslovJedan(c.Kategorija) as Kategorija;
            c.Korisnik = Sesija.Broker.dajSesiju().dajZaUslovJedan(c.Korisnik) as Korisnik;
            return c;
        }
    }
}
