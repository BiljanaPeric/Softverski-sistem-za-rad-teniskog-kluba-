﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.ClanSO
{
    public class KreirajClana : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            Clan c = new Clan();
            c.ClanID = Sesija.Broker.dajSesiju().dajSifru(c);
            Sesija.Broker.dajSesiju().sacuvaj(c);
            return c;
        }
    }
}
