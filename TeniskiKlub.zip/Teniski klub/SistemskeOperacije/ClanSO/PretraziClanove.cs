﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace SistemskeOperacije.ClanSO
{
    public class PretraziClanove : OpstaSO
    {
        public override object Izvrsi(OpstiDomenskiObjekat odo)
        {
            return Sesija.Broker.dajSesiju().dajSveZaUslovVise(odo).OfType<Clan>().ToList<Clan>();
           
        }
    }
}
