﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    public enum Status { NijeMenjano,Dodat,Obrisan, Izmenjen }
    [Serializable]
    public class Nagrada:OpstiDomenskiObjekat
    {
        int turnirID;
        int nagradaID;
        string naziv;
       
        [Browsable(false)]
        public int TurnirID
        {
            get
            {
                return turnirID;
            }

            set
            {
                turnirID = value;
            }
        }

        public int NagradaID
        {
            get
            {
                return nagradaID;
            }

            set
            {
                nagradaID = value;
            }
        }

        public string Naziv
        {
            get
            {
                return naziv;
            }

            set
            {
                naziv = value;
            }
        }

    
       
        #region ODO
        [Browsable(false)]
        public string tabela
        {
            get
            {
                return "Nagrada";
            }
        }
        [Browsable(false)]
        public string kljuc
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string uslovJedan
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string Uslov;
        [Browsable(false)]
        public string uslovVise
        {
            get
            {
                return Uslov;
            }
        }
        [Browsable(false)]
        public string azuriranje
        {
            get
            {
                return " NazivNagrade='" + Naziv + "";
            }
        }
        [Browsable(false)]
        public string upisivanje
        {
            get
            {
                return "  values (" + TurnirID + ","+nagradaID+",'"+Naziv+"')";
            }
        }

       

        public OpstiDomenskiObjekat napuni(DataRow red)
        {
            Nagrada n = new Nagrada();
            n.TurnirID = Convert.ToInt32(red["TurnirID"]);
            n.NagradaID = Convert.ToInt32(red["NagradaID"]);
            n.Naziv = red["NazivNagrade"].ToString();
           
            return n;
        }
        #endregion
    }
}
