﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Turnir:OpstiDomenskiObjekat
    {
        public override string ToString()
        {
            return mesto+" "+datum.Year;
        }


        public Turnir()
        {
            listaNagrada = new BindingList<Biblioteka.Nagrada>();
        }
        int turnirID;
        string mesto;
        DateTime datum;      
        BindingList<Nagrada> listaNagrada;

        [Browsable(false)]
        public int TurnirID
        {
            get
            {
                return turnirID;
            }

            set
            {
                turnirID = value;
            }
        }

        public string Mesto
        {
            get
            {
                return mesto;
            }

            set
            {
                mesto = value;
            }
        }

        public DateTime Datum
        {
            get
            {
                return datum;
            }

            set
            {
                datum = value;
            }
        }

       
        public BindingList<Nagrada> ListaNagrada
        {
            get
            {
                return listaNagrada;
            }

            set
            {
                listaNagrada = value;
            }
        }

        #region ODO
        [Browsable(false)]
        public string tabela
        {
            get
            {
                return "Turnir";
            }
        }
        [Browsable(false)]
        public string kljuc
        {
            get
            {
                return "TurnirID";
            }
        }
        [Browsable(false)]
        public string uslovJedan
        {
            get
            {
                return " TurnirID=" + TurnirID;
            }
        }
        [Browsable(false)]
        public string Uslov;
        [Browsable(false)]
        public string uslovVise
        {
            get
            {
                return Uslov;
            }
        }
        [Browsable(false)]
        public string azuriranje
        {
            get
            {
                return " Mesto='" + mesto + "', DatumOdrzavanja='" + datum.ToString("yyyy-MM-dd") + "'";
            }
        }
        [Browsable(false)]
        public string upisivanje
        {
            get
            {
                return " (TurnirID) values (" + TurnirID + ")";
            }
        }



        public OpstiDomenskiObjekat napuni(DataRow red)
        {
            Turnir t = new Turnir();
            t.TurnirID = Convert.ToInt32(red["TurnirID"]);
            t.Mesto = red["Mesto"].ToString();
            t.Datum = Convert.ToDateTime(red["DatumOdrzavanja"]);           
            return t;
        }
        #endregion
    }
}
