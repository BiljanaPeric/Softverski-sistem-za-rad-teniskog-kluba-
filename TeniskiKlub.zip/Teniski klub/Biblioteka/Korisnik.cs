﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Korisnik:OpstiDomenskiObjekat
    {
        public override string ToString()
        {
            return ime+" "+prezime;
        }

       

        string korisnikID;
        string ime;
        string prezime;
       

        [Browsable(false)]
        public string KorisnikID
        {
            get
            {
                return korisnikID;
            }

            set
            {
                korisnikID = value;
            }
        }

        public string Ime
        {
            get
            {
                return ime;
            }

            set
            {
                ime = value;
            }
        }

        public string Prezime
        {
            get
            {
                return prezime;
            }

            set
            {
                prezime = value;
            }
        }

       

        #region ODO
        [Browsable(false)]
        public string tabela
        {
            get
            {
                return "Korisnik";
            }
        }
        [Browsable(false)]
        public string kljuc
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string uslovJedan
        {
            get
            {
                return " SifraKorisnika='"+korisnikID+"'";
            }
        }
        [Browsable(false)]
        public string Uslov;
        [Browsable(false)]
        public string uslovVise
        {
            get
            {
                return Uslov;
            }
        }
        [Browsable(false)]
        public string azuriranje
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string upisivanje
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public OpstiDomenskiObjekat napuni(DataRow red)
        {
            Korisnik k = new Korisnik();
            k.KorisnikID = red["SifraKorisnika"].ToString();
            k.Ime = red["Ime"].ToString();
            k.Prezime = red["Prezime"].ToString();           
            return k;
        } 
        #endregion
    }
}
