﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    public enum Operacije { Kraj=1,
        PronadjiKorisnika = 2,
        KreirajClana = 3,
        ZapamtiClana = 4,
        ObrisiClana = 5,
        PretraziClanove = 6,
        PronadjiClana = 7,
        VratiSveKategorije = 8,
        VratiSveClanove = 9,      
        KreirajTurnir = 11,
        ZapamtiTurnir= 12,       
        PretraziTurnire = 14,
        UcitajTurnir = 15,
        ZapamtiPrijavu = 16,
        VratiSveTurnire = 17
    }
    [Serializable]
    public class TransferKlasa
    {
        Operacije operacija;

        public Operacije Operacija
        {
            get { return operacija; }
            set { operacija = value; }
        }
        Object transferObjekat;

        public Object TransferObjekat
        {
            get { return transferObjekat; }
            set { transferObjekat = value; }
        }
        Object rezultat;

        public Object Rezultat
        {
            get { return rezultat; }
            set { rezultat = value; }
        }
    }
}
