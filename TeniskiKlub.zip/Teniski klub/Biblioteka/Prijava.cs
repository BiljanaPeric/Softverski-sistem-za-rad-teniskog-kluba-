﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Prijava:OpstiDomenskiObjekat
    {


        Turnir turnir;
        Clan clan;
        DateTime datumPrijave;

        public Turnir Turnir { get => turnir; set => turnir = value; }
        public Clan Clan { get => clan; set => clan = value; }
        public DateTime DatumPrijave { get => datumPrijave; set => datumPrijave = value; }

        #region ODO
        [Browsable(false)]
        public string tabela
        {
            get
            {
                return "Prijava";
            }
        }
        [Browsable(false)]
        public string kljuc
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string uslovJedan
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string Uslov;
        [Browsable(false)]
        public string uslovVise
        {
            get
            {
                return Uslov;
            }
        }
        [Browsable(false)]
        public string azuriranje
        {
            get
            {
                return null;
            }
        }
        [Browsable(false)]
        public string upisivanje
        {
            get
            {
                return "Values ("+turnir.TurnirID+","+clan.ClanID+",'"+datumPrijave.ToString("yyyy-MM-dd")+"')";
            }
        }

       

        public OpstiDomenskiObjekat napuni(DataRow red)
        {
            return null;
        }
        #endregion
    }
}
