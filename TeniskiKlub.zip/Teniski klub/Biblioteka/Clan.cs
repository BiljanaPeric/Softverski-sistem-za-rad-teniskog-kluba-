﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Clan:OpstiDomenskiObjekat
    {
        public override bool Equals(object obj)
        {
            try
            {
                Clan c = obj as Clan;
                if (c.ClanID == this.ClanID) return true;
            }
            catch (Exception)
            {

                
            }
            return false;
        }

        public override string ToString()
        {
            return ime+" "+prezime;
        }

        int clanID;
        string ime;
        string prezime;
        DateTime datumRodjena;
        int clanskiBroj;
        string mail;
        Kategorija kategorija;
        Korisnik korisnik;

        [Browsable(false)]
        public int ClanID
        {
            get
            {
                return clanID;
            }

            set
            {
                clanID = value;
            }
        }

        public string Ime
        {
            get
            {
                return ime;
            }

            set
            {
                ime = value;
            }
        }

        public string Prezime
        {
            get
            {
                return prezime;
            }

            set
            {
                prezime = value;
            }
        }

        public DateTime DatumRodjena
        {
            get
            {
                return datumRodjena;
            }

            set
            {
                datumRodjena = value;
            }
        }
        [Browsable(false)]
        public Kategorija Kategorija
        {
            get
            {
                return kategorija;
            }

            set
            {
                kategorija = value;
            }
        }

        [Browsable(false)]
        public Korisnik Korisnik { get => korisnik; set => korisnik = value; }
        public int ClanskiBroj { get => clanskiBroj; set => clanskiBroj = value; }
        public string Mail { get => mail; set => mail = value; }

        #region ODO
        [Browsable(false)]
        public string tabela
        {
            get
            {
                return "Clan";
            }
        }
        [Browsable(false)]
        public string kljuc
        {
            get
            {
                return "ClanID";
            }
        }
        [Browsable(false)]
        public string uslovJedan
        {
            get
            {
                return " ClanID=" + clanID;
            }
        }
        [Browsable(false)]
        public string Uslov;
        [Browsable(false)]
        public string uslovVise
        {
            get
            {
                return Uslov;
            }
        }
        [Browsable(false)]
        public string azuriranje
        {
            get
            {
                return " Ime='"+ime+"', Prezime='"+prezime+"', DatumRodjenja='"+datumRodjena.ToShortDateString()+"', KategorijaID="+kategorija.KategorijaID+", KorisnikID='"+korisnik.KorisnikID+"', Mail='"+mail+"', ClanskiBroj="+clanskiBroj+"";
            }
        }
        [Browsable(false)]
        public string upisivanje
        {
            get
            {
                return " (ClanID) values ("+clanID+")";
            }
        }

     

        public OpstiDomenskiObjekat napuni(DataRow red)
        {
            Clan c = new Clan();
            c.clanID = Convert.ToInt32(red["ClanID"]);
            c.Ime = red["Ime"].ToString();
            c.Prezime = red["Prezime"].ToString();
            c.datumRodjena =Convert.ToDateTime( red["DatumRodjenja"]);
            c.Kategorija = new Kategorija();
            c.kategorija.KategorijaID=Convert.ToInt32( red["KategorijaID"]);
            c.Korisnik = new Korisnik();
            c.Korisnik.KorisnikID = red["KorisnikID"].ToString();
            c.Mail = red["Mail"].ToString();
            c.ClanskiBroj = Convert.ToInt32(red["ClanskiBroj"]);
            return c;
        }
        #endregion
    }
}
