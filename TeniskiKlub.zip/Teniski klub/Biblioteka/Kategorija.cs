﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Kategorija:OpstiDomenskiObjekat
    {
        public override bool Equals(object obj)
        {
            try
            {
                Kategorija k = obj as Kategorija;
                if (k.kategorijaID == this.kategorijaID) return true;
            }
            catch (Exception)
            {

                
            }
            return false;
        }

        public override string ToString()
        {
            return naziv;
        }
        int kategorijaID;
        string naziv;

        public int KategorijaID
        {
            get
            {
                return kategorijaID;
            }

            set
            {
                kategorijaID = value;
            }
        }

        public string Naziv
        {
            get
            {
                return naziv;
            }

            set
            {
                naziv = value;
            }
        }


        #region ODO
        public string tabela
        {
            get
            {
                return "Kategorija";
            }
        }

        public string kljuc
        {
            get
            {
                return null;
            }
        }

        public string uslovJedan
        {
            get
            {
                return " KategorijaID=" + kategorijaID;
            }
        }

        public string Uslov;
        public string uslovVise
        {
            get
            {
                return Uslov;
            }
        }

        public string azuriranje
        {
            get
            {
                return null;
            }
        }

        public string upisivanje
        {
            get
            {
                return null;
            }
        }

        public OpstiDomenskiObjekat napuni(DataRow red)
        {
            Kategorija k = new Kategorija();
            k.KategorijaID = Convert.ToInt32(red["KategorijaID"]);
            k.Naziv = red["Naziv"].ToString();           
            return k;
        }
        #endregion
    }
}
