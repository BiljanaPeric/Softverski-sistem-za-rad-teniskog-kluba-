﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net.Sockets;
using Biblioteka;

namespace Komunikacija
{
    public class Komunikacija
    {
        TcpClient klijent;
        BinaryFormatter formater;
        NetworkStream tok;

        public bool poveziSeNaServer()
        {
            try
            {
                klijent = new TcpClient("127.0.0.1", 20000);
                tok = klijent.GetStream();
                formater = new BinaryFormatter();
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }


        public void kraj() 
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.Kraj;
            formater.Serialize(tok, transfer);
        }

        public Object pronadjiKorisnika(Korisnik k)
        {
            // slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.PronadjiKorisnika;
            transfer.TransferObjekat = k;
            formater.Serialize(tok, transfer);

            // prijem
            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }


        public Object kreirajClana()
        {
           
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.KreirajClana;
            transfer.TransferObjekat = new Clan();
            formater.Serialize(tok, transfer);
            
            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public object zapamtiPrijavu(Prijava p)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiPrijavu;
            transfer.TransferObjekat = p;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object zapamtiClana(Clan c)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiClana;
            transfer.TransferObjekat = c;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object obrisiClana(Clan c)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ObrisiClana;
            transfer.TransferObjekat = c;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object pronadjiClana(Clan c)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.PronadjiClana;
            transfer.TransferObjekat = c;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object pretraziClanove(Clan c)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.PretraziClanove;
            transfer.TransferObjekat = c;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object vratiSveKategorije()
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiSveKategorije;
            transfer.TransferObjekat = new Kategorija();
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object vratiSveClanove()
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiSveClanove;
            transfer.TransferObjekat = new Clan();
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object vratiSveTurnire()
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiSveTurnire;
            transfer.TransferObjekat = new Turnir();
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object kreirajTurnir()
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.KreirajTurnir;
            transfer.TransferObjekat = new Turnir();
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object zapamtiTurnir(Turnir e)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiTurnir;
            transfer.TransferObjekat = e;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

      

        public Object pretraziTurnire(Turnir t)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.PretraziTurnire;
            transfer.TransferObjekat = t;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object pronadjiTurnir(Turnir e)
        {

            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.UcitajTurnir;
            transfer.TransferObjekat = e;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }
    }
}
