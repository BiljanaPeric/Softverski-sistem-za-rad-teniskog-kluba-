﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Unos_prijave : Form
    {
        KontrolerKorisnickogInterfejsa.KontrolerKI kki = new KontrolerKorisnickogInterfejsa.KontrolerKI();
        public Unos_prijave()
        {
            InitializeComponent();
        }

        private void Unos_prijave_Load(object sender, EventArgs e)
        {
            kki.PopuniCombo(cmbClan,cmbTurnir);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kki.zapamtiPrijavu(cmbTurnir, cmbClan)) this.Close();
        }
    }
}
