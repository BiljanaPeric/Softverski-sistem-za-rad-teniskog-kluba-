﻿namespace Klijent
{
    partial class GlavnaForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.takmicarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unosTakmicaraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pregledTakmicaraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.takmicenjeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unosTakmicenjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pretragatakmicenjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prijavaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unosPrijaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.krajRadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.takmicarToolStripMenuItem,
            this.takmicenjeToolStripMenuItem,
            this.prijavaToolStripMenuItem,
            this.krajRadaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(604, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // takmicarToolStripMenuItem
            // 
            this.takmicarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosTakmicaraToolStripMenuItem,
            this.pregledTakmicaraToolStripMenuItem});
            this.takmicarToolStripMenuItem.Name = "takmicarToolStripMenuItem";
            this.takmicarToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.takmicarToolStripMenuItem.Text = "Clan";
            // 
            // unosTakmicaraToolStripMenuItem
            // 
            this.unosTakmicaraToolStripMenuItem.Name = "unosTakmicaraToolStripMenuItem";
            this.unosTakmicaraToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.unosTakmicaraToolStripMenuItem.Text = "Unos clana";
            this.unosTakmicaraToolStripMenuItem.Click += new System.EventHandler(this.unosClanaToolStripMenuItem_Click);
            // 
            // pregledTakmicaraToolStripMenuItem
            // 
            this.pregledTakmicaraToolStripMenuItem.Name = "pregledTakmicaraToolStripMenuItem";
            this.pregledTakmicaraToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.pregledTakmicaraToolStripMenuItem.Text = "Pregled clanova";
            this.pregledTakmicaraToolStripMenuItem.Click += new System.EventHandler(this.pregledClanaToolStripMenuItem_Click);
            // 
            // takmicenjeToolStripMenuItem
            // 
            this.takmicenjeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosTakmicenjaToolStripMenuItem,
            this.pretragatakmicenjaToolStripMenuItem});
            this.takmicenjeToolStripMenuItem.Name = "takmicenjeToolStripMenuItem";
            this.takmicenjeToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.takmicenjeToolStripMenuItem.Text = "Turnir";
            // 
            // unosTakmicenjaToolStripMenuItem
            // 
            this.unosTakmicenjaToolStripMenuItem.Name = "unosTakmicenjaToolStripMenuItem";
            this.unosTakmicenjaToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.unosTakmicenjaToolStripMenuItem.Text = "Unos turnir";
            this.unosTakmicenjaToolStripMenuItem.Click += new System.EventHandler(this.unosEkspedicijeToolStripMenuItem_Click);
            // 
            // pretragatakmicenjaToolStripMenuItem
            // 
            this.pretragatakmicenjaToolStripMenuItem.Name = "pretragatakmicenjaToolStripMenuItem";
            this.pretragatakmicenjaToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.pretragatakmicenjaToolStripMenuItem.Text = "Pretraga turnira";
            this.pretragatakmicenjaToolStripMenuItem.Click += new System.EventHandler(this.pretragaEkspedicijeToolStripMenuItem_Click);
            // 
            // prijavaToolStripMenuItem
            // 
            this.prijavaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosPrijaveToolStripMenuItem});
            this.prijavaToolStripMenuItem.Name = "prijavaToolStripMenuItem";
            this.prijavaToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.prijavaToolStripMenuItem.Text = "Prijava";
            // 
            // unosPrijaveToolStripMenuItem
            // 
            this.unosPrijaveToolStripMenuItem.Name = "unosPrijaveToolStripMenuItem";
            this.unosPrijaveToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.unosPrijaveToolStripMenuItem.Text = "Unos prijave";
            this.unosPrijaveToolStripMenuItem.Click += new System.EventHandler(this.unosPrijaveToolStripMenuItem_Click);
            // 
            // krajRadaToolStripMenuItem
            // 
            this.krajRadaToolStripMenuItem.Name = "krajRadaToolStripMenuItem";
            this.krajRadaToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.krajRadaToolStripMenuItem.Text = "Kraj rada";
            this.krajRadaToolStripMenuItem.Click += new System.EventHandler(this.krajRadaToolStripMenuItem_Click);
            // 
            // GlavnaForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(604, 350);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GlavnaForma";
            this.Text = "GlavnaForma";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.GlavnaForma_FormClosed);
            this.Load += new System.EventHandler(this.GlavnaForma_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem takmicarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem takmicenjeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem krajRadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unosTakmicaraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pregledTakmicaraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unosTakmicenjaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pretragatakmicenjaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prijavaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unosPrijaveToolStripMenuItem;
    }
}