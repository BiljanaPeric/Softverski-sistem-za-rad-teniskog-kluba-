﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Klijent
{
    public partial class GlavnaForma : Form
    {
        KontrolerKorisnickogInterfejsa.KontrolerKI kki = new KontrolerKorisnickogInterfejsa.KontrolerKI();
        public GlavnaForma()
        {
            InitializeComponent();
        }

        private void krajRadaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void GlavnaForma_FormClosed(object sender, FormClosedEventArgs e)
        {
            kki.kraj();
        }

        private void GlavnaForma_Load(object sender, EventArgs e)
        {
            this.Text = " Ulogovan je " + KontrolerKorisnickogInterfejsa.KontrolerKI.korisnik.ToString();
        }

        private void unosClanaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new UnosClana().ShowDialog();
        }

        private void pregledClanaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new PregledClanova().ShowDialog();
        }

        private void unosEkspedicijeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new UnosTurnira().ShowDialog();
        }

        private void pretragaEkspedicijeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new PretragaTurnira().ShowDialog();
        }

        private void unosPrijaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Unos_prijave().ShowDialog();
        }
    }
}
