﻿namespace Klijent
{
    partial class Unos_prijave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbClan = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbTurnir = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbClan
            // 
            this.cmbClan.FormattingEnabled = true;
            this.cmbClan.Location = new System.Drawing.Point(103, 23);
            this.cmbClan.Name = "cmbClan";
            this.cmbClan.Size = new System.Drawing.Size(305, 21);
            this.cmbClan.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Clan:";
            // 
            // cmbTurnir
            // 
            this.cmbTurnir.FormattingEnabled = true;
            this.cmbTurnir.Location = new System.Drawing.Point(103, 61);
            this.cmbTurnir.Name = "cmbTurnir";
            this.cmbTurnir.Size = new System.Drawing.Size(305, 21);
            this.cmbTurnir.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Turnir:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(19, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(389, 41);
            this.button1.TabIndex = 19;
            this.button1.Text = "Dodaj prijavu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Unos_prijave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(439, 183);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbTurnir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbClan);
            this.Controls.Add(this.label6);
            this.Name = "Unos_prijave";
            this.Text = "Unos_prijave";
            this.Load += new System.EventHandler(this.Unos_prijave_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbClan;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbTurnir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}