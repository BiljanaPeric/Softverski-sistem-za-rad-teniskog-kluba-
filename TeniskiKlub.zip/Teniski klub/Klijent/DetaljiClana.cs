﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Klijent
{
    public partial class DetaljiClana : Form
    {
        KontrolerKorisnickogInterfejsa.KontrolerKI kki = new KontrolerKorisnickogInterfejsa.KontrolerKI();
        public DetaljiClana()
        {
            InitializeComponent();
        }

        private void DetaljiClana_Load(object sender, EventArgs e)
        {
            kki.popuniDetaljeClana(txtIme,txtPrezime,dtpDatum,cmbZemlja, txtClanBR,txtMail);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (kki.zapamtiClana(txtIme, txtPrezime, dtpDatum, cmbZemlja,txtMail,txtClanBR)) this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kki.obrisiClana()) this.Close();
        }
    }
}
