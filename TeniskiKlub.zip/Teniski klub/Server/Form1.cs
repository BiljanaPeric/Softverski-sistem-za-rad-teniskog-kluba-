﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Server
{
    public partial class Form1 : Form
    {
        Server s;
        Timer t;
        public Form1()
        {
          
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Server nije pokrenut!";
        }

        private void btnPokreni_Click(object sender, EventArgs e)
        {
            s = new Server();
            if (s.pokreniServer())
            {
                this.Text = "Pokrenut!";
                t = new Timer();
                t.Interval = 3000;
                t.Tick += osvezi;
                t.Start();
                btnPokreni.Enabled = false;
                btnZaustavi.Enabled = true;
            }
        }

        private void osvezi(object sender, EventArgs e)
        {
            List<Korisnik> lista = new List<Korisnik>();
            foreach (Korisnik d in Server.listaUlogovanihKorisnika) lista.Add(d);
            dataGridView1.DataSource = lista;
        }

        private void btnZaustavi_Click(object sender, EventArgs e)
        {
            if (Server.listaUlogovanihKorisnika.Count > 0)
            {
                MessageBox.Show("Postoje ulogovani delegati!");
                return;
            }

            if (s.zaustaviServer())
            {
                this.Text = "Server nije pokrenut!";
                t.Stop();
                btnPokreni.Enabled = true;
                btnZaustavi.Enabled = false;
            }
        }
    }
}
