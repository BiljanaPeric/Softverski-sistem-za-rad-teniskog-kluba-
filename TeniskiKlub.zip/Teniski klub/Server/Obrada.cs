﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using Biblioteka;
using Sesija;
using System.Threading;
using SistemskeOperacije.LoginSO;
using SistemskeOperacije.ClanSO;
using SistemskeOperacije.TurnirSO;
using SistemskeOperacije.PrijavaSO;

namespace Server
{
    public class Obrada
    {
        BinaryFormatter formater;
        NetworkStream tok;
        Korisnik k;

        public Obrada(NetworkStream tok)
        {
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradiKlijenta;
            Thread nit = new Thread(ts);
            nit.Start();
        }

        public void obradiKlijenta() 
        {
            try
            {
                int operacija = 0;
                while (operacija != (int)Operacije.Kraj)
                {
                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;
                    switch (transfer.Operacija)
                    {
                        case Operacije.PronadjiKorisnika:
                            PronadjiKorisnika pd = new PronadjiKorisnika();
                            transfer.Rezultat = pd.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            k = transfer.Rezultat as Korisnik;
                            if (k != null) Server.listaUlogovanihKorisnika.Add(k);
                            break;

                        case Operacije.KreirajClana:
                            KreirajClana kt = new KreirajClana();
                            transfer.Rezultat = kt.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.ZapamtiClana:
                            ZapamtiClana zt = new ZapamtiClana();
                            transfer.Rezultat = zt.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.ObrisiClana:
                            ObrisiClana ot = new ObrisiClana();
                            transfer.Rezultat = ot.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.PretraziClanove:
                            PretraziClanove pt = new PretraziClanove();
                            transfer.Rezultat = pt.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.PronadjiClana:
                            UcitajClana prot = new UcitajClana();
                            transfer.Rezultat = prot.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.VratiSveKategorije:
                            VratiSveKategorije vsk = new VratiSveKategorije();
                            transfer.Rezultat = vsk.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.VratiSveClanove:
                            VrtatiSveClanove vst = new VrtatiSveClanove();
                            transfer.Rezultat = vst.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                     

                        case Operacije.KreirajTurnir:
                            KreirajTurnir krt = new KreirajTurnir();
                            transfer.Rezultat = krt.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.ZapamtiTurnir:
                            ZapamtiTurnir ztk = new ZapamtiTurnir();
                            transfer.Rezultat = ztk.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                                                 
                        case Operacije.PretraziTurnire:
                            PretraziTurnire ptt = new PretraziTurnire();
                            transfer.Rezultat = ptt.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.UcitajTurnir:
                            UcitajTurnir prt = new UcitajTurnir();
                            transfer.Rezultat = prt.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.ZapamtiPrijavu:
                            ZapamtiPrijavu zpr = new ZapamtiPrijavu();
                            transfer.Rezultat = zpr.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.VratiSveTurnire:
                            VratiSveTurnire vs = new VratiSveTurnire();
                            transfer.Rezultat = vs.izvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.Kraj:
                            operacija = 1;
                            Server.listaUlogovanihKorisnika.Remove(k);
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception)
            {

                Server.listaUlogovanihKorisnika.Remove(k);
            }
        }
    }
}
